package com.lucifiere.platform.constant;

/**
 * The interface Bef constants.
 *
 * @author XD.Wang
 */
public interface BefConstants {

    /**
     * The constant PLATFORM_PRODUCT_CODE.
     */
    String PLATFORM_PRODUCT_CODE = "PlatformProduct";
}
