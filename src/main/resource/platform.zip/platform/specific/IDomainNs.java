package com.lucifiere.platform.specific;

/**
 * 业务域的命名空间
 *
 * @author XD.Wang
 */
public interface IDomainNs {

    /**
     * Gets code.
     *
     * @return the code
     */
    String getCode();

}
