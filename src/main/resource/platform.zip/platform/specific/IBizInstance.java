package com.lucifiere.platform.specific;

import com.lucifiere.platform.specific.impl.BizInstanceId;

/**
 * 业务实例
 *
 * @author XD.Wang
 */
public interface IBizInstance {

    /**
     * Gets biz instance id.
     *
     * @return the biz instance id
     */
    BizInstanceId getBizInstanceId();
}
