package com.lucifiere.platform.specific;

import java.util.function.Function;

/**
 * The interface Extension callback.
 *
 * @param <T> the type parameter
 * @param <R> the type parameter
 * @author XD.Wang
 */
public interface ExtensionCallback<T extends IExtensionPoints, R> extends Function<T, R> {

}
