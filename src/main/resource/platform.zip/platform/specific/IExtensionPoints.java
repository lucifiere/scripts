package com.lucifiere.platform.specific;

/**
 * 扩展点接口
 *
 * @author XD.Wang
 */
public interface IExtensionPoints {

}
